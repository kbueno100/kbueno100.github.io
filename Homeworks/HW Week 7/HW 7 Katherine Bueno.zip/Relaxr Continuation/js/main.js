$('#yellow').on('submit', newPage);
$('#blue').on('submit', newPage);

function newPage() {
	
}

